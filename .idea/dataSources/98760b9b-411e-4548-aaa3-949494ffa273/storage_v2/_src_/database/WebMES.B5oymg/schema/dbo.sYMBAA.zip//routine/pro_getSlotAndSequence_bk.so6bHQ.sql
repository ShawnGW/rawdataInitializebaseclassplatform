Create   procedure [dbo].[pro_getSlotAndSequence_bk]
@lotid varchar(50)
as
	select isnull( c.Wafer_Sequence,'1-25')  sequence,a.read_type,(case when (b.gpib_bin is null or b.gpib_bin ='' or b.gpib_bin ='NA' )  then 'NA' else SUBSTRING(b.gpib_bin,1,1) end) gpib_bin
		from  (SELECT    top 1 isnull(max(case when  ((flex1.ItemValue1='') or (flex1.ItemValue1=null) ) then 'OCR'  else upper(flex1.ItemValue1)  end),'OCR') read_type
  FROM [WebMES].[dbo].[pdm_FlexibleItems] flex1, (select ProcessFlow+':'+ CAST(ProcessRevision as nvarchar(10)) process,WaferSequence 
  from [WebMES].[dbo].[wip_LotList]  where CustLotNum = @lotid   and ProcessFlow not like '%DEFAULT%' ) wplist
   where flex1.ItemName='WaferID_read' and wplist.process=flex1.ItemOwner  
    and flex1.Flag=1 ) a,
	(SELECT   top 1 isnull(max(case when  ((flex1.ItemValue1='') or (flex1.ItemValue1=null) ) then '0'  else flex1.ItemValue1  end),'0')  gpib_bin
  FROM [WebMES].[dbo].[pdm_FlexibleItems] flex1, (select ProcessFlow+':'+ CAST(ProcessRevision as nvarchar(10)) process,WaferSequence 
  from [WebMES].[dbo].[wip_LotList]  where CustLotNum = @lotid  and ProcessFlow not like '%DEFAULT%' ) wplist
   where flex1.ItemName='GPIB_Bin' and wplist.process=flex1.ItemOwner  
    and flex1.Flag=1 ) b,
	(SELECT top 1  WaferSequence  Wafer_Sequence
  from [WebMES].[dbo].[wip_LotList]  where CustLotNum = @lotid   and ProcessFlow not like '%DEFAULT%')c;
go

