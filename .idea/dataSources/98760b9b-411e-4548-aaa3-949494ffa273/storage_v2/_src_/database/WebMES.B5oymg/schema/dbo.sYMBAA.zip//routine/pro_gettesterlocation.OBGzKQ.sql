CREATE   procedure [dbo].[pro_gettesterlocation]
as
  select tester.name,prober.[LocationX] x,prober.[LocationY] y,
 tester. location,tester.EQtype
  from (SELECT [MachineID] name,[LocationX] x
      ,[LocationY] y ,[SiteLocation] location
      ,[MachineType] EQtype ,[LinkedMachine]
  FROM [WebMES].[dbo].[EQP_MachineList] where SiteLocation is not null and isActive=1 
  and [LocationX] is not null and [LocationY] is not null and [MachineType]='Tester'
  and MachineType in ('Tester','Prober')) tester, [WebMES].[dbo].[EQP_MachineList] prober
  where tester.[LinkedMachine]=prober.[MachineID] and prober.isActive=1
  and  prober.SiteLocation is not null and prober.[LocationX] is not null
   and prober.[LocationY] is not null and prober.[MachineType]='prober' and name <>'TTG-03' and  name<>'TTH-53'
   order by tester.name
go

