
CREATE   procedure [dbo].[pro_getBinColor] 

as

  select  top 100  Color_RGB  from [VTEST].[dbo].[Color_Mapping]

go

