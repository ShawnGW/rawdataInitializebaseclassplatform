Create   procedure [dbo].[pro_GetWaferInfo_Backup]
@waferid varchar(50),
@cpstep varchar(50)
as

select   top 1 wftotl.lot_id, wftotl.inner_lot,wftotl.inner_monther_lot,wftotl.customer_code, 
 wftotl.device_name,wftotl.wafer_id,wftotl.lot_starttime,flexconf.pe_owner ,isnull(flexconf.tester_SoftWare_revision,'NA') tester_SoftWare_revision,isnull(flexconf.Tester_Model,'NA') tester_model,wftotl.chinese_name,wftotl.chinese_shortname,
wftotl.part_num, wftotl.process_spec,wftotl.process_revision,wftotl.worker_order,wftotl.lot_status,wftotl.wip_stage,
wftotl.wip_step,wftotl.po_number,wftotl.customer_to_customer_po_number,isnull(wftotl.part_desc,'NA') part_desc,wftotl.map_or_ink,wftotl.is_otp ,wftotl.is_cop,wftotl.fab_device,wftotl.asy_device, 
wftotl.ship_lot,wftotl.assigned_testers ,wftotl.is_trimed,
isnull(flexconf.load_file,'NA') load_file,isnull(flexconf.customer_tester_spec,'NA') customer_tester_spec, isnull(flexconf.map_reference,'NA') map_reference,
isnull(prosque.shortflowid ,'NA') process_short_flow,
wftotl.wafer_pcs,isnull(wafspec.Sites,'NA') sites, isnull( flexconf.site_to_site,'NA') site_to_site,isnull(flexconf.continue_fail,'NA') continue_fail,
wftotl.prober_device, 'NA' operator, isnull( recpid.testerprogram,'NA') tester_program, isnull(recpid.AllcpProcess,'NA') all_cp_programs,isnull(recpid.testerid,'NA')  tester_id,
isnull( recpid.proberid,'NA')  prober_id,isnull( recpid.cardid,'NA') prober_card_id, 'NA' cp_process, wftotl.hold_count, 'NA' test_start_time,'NA' test_end_time,
wftotl.test_gross_die,wftotl.stand_gross_die,'NA' gross_die,'NA' pass_die,'NA' fail_die, 'NA' wafer_yield,
 (case when (flexconf.stop_yield is null or flexconf.stop_yield ='' or flexconf.stop_yield ='NA' )  then 'NA'  when CHARINDEX('CP',flexconf.stop_yield )<=0 then flexconf.stop_yield
  when CHARINDEX(@cpstep,flexconf.stop_yield )<=0 then 'NA' else
(SUBSTRING(flexconf.stop_yield ,CHARINDEX(@cpstep,flexconf.stop_yield )+4,2 )) end )  stop_yield,
isnull(flexconf.major_fail,'NA') major_fail,isnull(wafspec.controlspec,'NA|NA') process_yield,isnull(yieldinfo.Yieldcon,'NA' ) cp_yield,isnull(wftotl.pass_bins,'NA' ) pass_bins,
--isnull(wftotl.os_bins,'NA' ) os_bins, 
--isnull(flexconf.special_bins,'NA')     special_bins,
(case when (wftotl.OSBinsNew is null or wftotl.OSBinsNew ='' or wftotl.OSBinsNew ='NA' )  then wftotl.OSBinsNew else wftotl.OSBinsNew end) os_bins,
(case when (wftotl.SpecialBins is null or wftotl.SpecialBins ='' or wftotl.SpecialBins ='NA' )  then flexconf.special_bins else wftotl.SpecialBins end) special_bins,
 (case when (flexconf.theory_test_time is null or flexconf.theory_test_time ='' or flexconf.theory_test_time ='NA' )  then 'NA'  when CHARINDEX('CP',flexconf.theory_test_time )<=0 
 then flexconf.theory_test_time  when CHARINDEX(@cpstep,flexconf.theory_test_time )<=0 then 'NA' else
(SUBSTRING(flexconf.theory_test_time ,CHARINDEX(@cpstep,flexconf.theory_test_time )+4,4 )) end )   theory_test_time,
'NA' retest_rate, 'NA' data_base,'NA' test_time,wftotl.wafer_id_read,wafer_sequence,wftotl.wf_size,wftotl.index_x,wftotl.index_y,
'NA' map_cols,'NA' map_rows,(case when (wftotl.gpib_bin is null or wftotl.gpib_bin ='' or wftotl.gpib_bin ='NA' )  then 'NA' else SUBSTRING(wftotl.gpib_bin,1,1) end) gpib_bin,
wftotl.notch, wftotl.customer_notch  customer_notch,wftotl.slot,
(case when wafer_sequence='25-1'then 26-wftotl.SlotNum else wftotl.SlotNum end) right_id,
'NA' minx,'NA' miny,'NA' maxx ,'NA' maxy,'NA' test_die_minx,'NA' test_die_miny, 'NA' test_die_maxx,'NA' test_die_maxy
 FROM 
	(  select aa.lot_id, aa.inner_lot,aa.inner_monther_lot,aa.customer_code, 
aa.device_name,aa.wafer_id,aa.lot_starttime,aa.hold_count,aa.notch,aa.tester_model,aa.chinese_name,aa.chinese_shortname, aa.SpecialBins,aa.OSBinsNew,
aa.part_num, aa.process_spec,aa.process_revision,aa.worker_order,aa.lot_status,aa.wip_stage,aa.wip_step,workor.PONumber po_number,
(case when (aa.part_desc is null or aa.part_desc ='') then 'NA' end) part_desc,  aa.wafer_sequence,  aa.wafer_id_read,aa.gpib_bin,aa.customer_notch ,
aa.map_or_ink,aa.is_otp,aa.is_cop,aa.fab_device,aa.SlotNum ,aa.asy_device,-- (case when (workor.CustLotPostCP is null or workor.CustLotPostCP ='') then
 --aa.ship_lot else workor.CustLotPostCP end)
 aa.ship_lot  ship_lot,
 aa.assigned_testers,aa.is_trimed,aa.wafer_pcs, 
(case when (aa.prober_device is null or aa.prober_device ='' or aa.prober_device ='NA' )  then 'NA'  
when ((len(aa.prober_device)<4)  or (CHARINDEX(@cpstep,aa.prober_device )<1 )) then aa.prober_device else 
(SUBSTRING( SUBSTRING(aa.prober_device,CHARINDEX(@cpstep,aa.prober_device )+4,len(aa.prober_device ) ),1,
case when CHARINDEX(';',SUBSTRING(aa.prober_device ,CHARINDEX(@cpstep,aa.prober_device )+4,len(aa.prober_device ) ) )>1 then
CHARINDEX(';',SUBSTRING(aa.prober_device ,CHARINDEX(@cpstep,aa.prober_device )+4,len(aa.prober_device ) ) )-1
else len(SUBSTRING(aa.prober_device ,CHARINDEX(@cpstep,aa.prober_device )+4,len(aa.prober_device ) ))  end ))
  end ) prober_device,
aa.test_gross_die,aa.stand_gross_die,aa.pass_bins,
(case when (os_binsraw is null or os_binsraw ='' or os_binsraw ='NA' )  then 'NA'  when ((len(os_binsraw)<4) or (CHARINDEX(@cpstep,os_binsraw )<1))  then os_binsraw else 
(SUBSTRING( SUBSTRING(os_binsraw,CHARINDEX(@cpstep,os_binsraw )+4,len(os_binsraw ) ),1,
case when CHARINDEX(';',SUBSTRING(os_binsraw ,CHARINDEX(@cpstep,os_binsraw )+4,len(os_binsraw ) ) )>1 then
CHARINDEX(';',SUBSTRING(os_binsraw ,CHARINDEX(@cpstep,os_binsraw )+4,len(os_binsraw ) ) )-1
else len(SUBSTRING(os_binsraw ,CHARINDEX(@cpstep,os_binsraw )+4,len(os_binsraw ) ))  end ) )    end ) os_bins,
aa.wf_size,aa. index_x,aa. index_y,aa.Item_Index,aa.slot, isnull(max(case when ( workor.CustCustPO  is null or  workor.CustCustPO  ='' ) 
   then 'NA' else  workor.CustCustPO  end ),'NA')  customer_to_customer_po_number  from
 ( select wplist.CustLotNum lot_id, wplist.LotNum inner_lot,wplist.MotherLot inner_monther_lot,wplist.CustCode customer_code, 
 wplist.CustPart device_name,wfl.WaferID wafer_id,max(StartTime) lot_starttime, wplist.HoldCount hold_count,prdevic.WaferNotch notch,
 isnull(max(case when (procflow.TesterModel is null or procflow.TesterModel ='' )  then 'NA' else procflow.TesterModel  end ),'NA') tester_model,
 isnull(max(case when ( cust.CustCName  is null or  cust.CustCName  ='' )  then 'NA' else  cust.CustCName  end ),'NA') chinese_name,
 isnull(max(case when ( cust.ShortName  is null or  cust.ShortName  ='' )  then 'NA' else  cust.ShortName  end ),'NA') chinese_shortname,
pn.PartNumber part_num, wplist.ProcessFlow process_spec,wplist.ProcessRevision process_revision,
isnull(max(case when ( wplist.WorkOrder  is null or  wplist.WorkOrder  ='' )  then 'NA' else  wplist.WorkOrder  end ),'NA') worker_order,wplist.LotStatus lot_status,
isnull(max(case when ( wplist.WipStage  is null or  wplist.WipStage  ='' )  then 'NA' else  wplist.WipStage  end ),'NA') wip_stage,
isnull(max(case when ( wplist.WipStep  is null or  wplist.WipStep  ='' )  then 'NA' else  wplist.WipStep  end ),'NA') wip_step,wplist.PONumber po_number,pn.PartDescription part_desc, 
isnull(max(case when ( pn.MapOrInk  is null or  pn.MapOrInk ='' )  then 'NA' else  pn.MapOrInk  end ),'NA') map_or_ink,
isnull(max(case when ( procflow.isOTP  is null or  procflow.isOTP  ='' )  then 0 else  procflow.isOTP  end ),0) is_otp,
isnull(max(case when ( procflow.isCUP  is null or  procflow.isCUP  ='' )  then 0 else  procflow.isCUP  end ),0) is_cop,
isnull(max(case when ( pn.FabDevice  is null or  pn.FabDevice  ='' )  then 'NA' else  pn.FabDevice  end ),'NA') fab_device,
wfl.SlotNum ,
isnull(max(case when ( pn.AsyDevice  is null or  pn.AsyDevice  ='' )  then 'NA' else  pn.AsyDevice  end ),'NA') asy_device, 
isnull(max(case when ( xx.CustLotPostCP  is not null or  xx.CustLotPostCP  <>'' )  then xx.CustLotPostCP else  invent.V_LotNum  end ),'NA')   ship_lot,
isnull(max(case when ( pn.AssignedTesters  is null or  pn.AssignedTesters  ='' )  then 'NA' else  pn.AssignedTesters  end ),'NA') assigned_testers,
isnull(max(case when ( procflow.isTrimed  is null or  procflow.isTrimed  ='' )  then 0 else  procflow.isTrimed  end ),0) is_trimed,
wplist.PCS wafer_pcs, seque.ProberDevice prober_device,prdevic.GrossDie test_gross_die,procflow.GrossDie stand_gross_die,
isnull(max(case when ( seque.OSBins  is null or  seque.OSBins  ='' )  then 'NA' else seque.OSBins  end ),'NA') OSBinsNew,
isnull(max(case when ( prdevic.PassBins  is null or  prdevic.PassBins  ='' )  then 'NA' else  prdevic.PassBins  end ),'NA') pass_bins,
isnull(max(case when ( prdevic.SpecialBins  is null or  prdevic.SpecialBins  ='' )  then 'NA' else  prdevic.SpecialBins  end ),'NA') SpecialBins,
 isnull(max(case when ( pn.CpxOsBins  is null or  pn.CpxOsBins  ='' )  then pn.OpenShortBinCode else  pn.CpxOsBins  end ),'NA') os_binsraw,
isnull(max(case when ( pn.WaferSize  is null or  pn.WaferSize  ='' )  then 'NA' else  pn.WaferSize  end ),'NA') wf_size,
isnull(max(case when ( prdevic.DieSize_X is null or  prdevic.DieSize_X  ='' )  then  0 else  prdevic.DieSize_X  end ),0) index_x,
isnull(max(case when ( prdevic.DieSize_Y  is null or  prdevic.DieSize_Y  ='' )  then 0 else  prdevic.DieSize_Y  end ),0) index_y,
isnull(max(case when ( prdevic.WaferRead  is null or  prdevic.WaferRead  ='' )  then 'NA' else  prdevic.WaferRead  end ),'NA') wafer_id_read,
isnull(max(case when ( prdevic.GbibBin  is null or  prdevic.GbibBin  ='' )  then 'NA' else  prdevic.GbibBin  end ),'NA') gpib_bin,
isnull(max(case when ( procflow.ReportNotch  is null or  procflow.ReportNotch  ='' )  then 'NA' else  procflow.ReportNotch  end ),'NA')  customer_notch,

wplist.WaferSequence wafer_sequence,procflow.Item_Index,wfl.SlotNum slot from 
[WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl, [WebMES].[dbo].pdm_Products pn ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
[WebMES].[dbo].[pdm_ProcessFlows] procflow,[WebMES].[dbo].[pdm_Customers] cust,[WebMES].[dbo].[pdm_ProberDevice] prdevic,
[WebMES].[dbo].[whm_Inventory] invent,(SELECT  custcode, isnull(max(case when ( CustLotPostCP  is null or CustLotPostCP  ='' )  then 
   [WebMES].[dbo].[wip_LotList].CustLotNum else  CustLotPostCP  end ),'NA')  CustLotPostCP
	  FROM [WebMES].[dbo].[wip_LotList] inner join  [WebMES].[dbo].[wip_LotWaferIDs] 
	on [WebMES].[dbo].[wip_LotList].LotNum=[WebMES].[dbo].[wip_LotWaferIDs].LotNum  where WaferID=@waferid and LotStatus>0 group by custcode) xx
where wplist.CustLotNum=wfl.[WaferLot] and wfl.WaferID=@waferid  
and prdevic.isActive=1 and seque.isActive=1 and  seque.FlowIndex=procflow.Item_Index and seque.ProberDevice=prdevic.ProberDeviceName 
 and wplist.ProcessFlow=procflow.ProcessFlowName and procflow.isActive=1 and wplist.ProcessRevision=procflow.Revision
 and pn.CustCode=cust.CustCode-- and invent.ProcessFlowName=wplist.ProcessFlow --and wplist.ProcessRevision=invent.Revision 
 and wfl.LotNum=wplist.LotNum and wplist.ProcessFlow=procflow.ProcessFlowName and wplist.ProcessRevision=procflow.Revision  
and wplist.LotStatus>0  
 and cust.isActive=1 and   invent.PartNumber=wplist.PartNumber and xx.CustCode=pn.CustCode
and LotCat<>'I' and LotCat<>'R' 
 and seque.StepCode like @cpstep+'%' and prdevic.IsDefault=1 and seque.OSBins is not null and seque.OSBins <>''
 And wplist.LotStatus in (-8,0,1,8,9,10,99) and  pn.isActive = 1 and pn.PartNumber=wplist.PartNumber  
 --and wfl.SetTime in (select  max(settime)SetTime FROM [WebMES].[dbo].wip_LotWaferIDs INNER JOIN [WebMES].[dbo].wip_LotList ON wip_LotWaferIDs.LotNum = wip_LotList.LotNum
--WHERE   (wip_LotWaferIDs.WaferID = @waferid ) AND (wip_LotList.LotCat NOT IN ('R', 'I')))
 group by wplist.CustLotNum , wplist.LotNum ,wplist.MotherLot ,wplist.CustCode , wplist.CustPart ,wfl.WaferID ,wplist.WaferSequence,prdevic.WaferNotch,
 pn.PartNumber , wplist.ProcessFlow ,wplist.ProcessRevision ,wplist.LotStatus ,pn.WaferNotch, wplist.HoldCount,wplist.PONumber ,pn.PartDescription , 
 invent.V_LotNum ,wplist.PCS ,seque.ProberDevice ,prdevic.GrossDie ,procflow.GrossDie, procflow.Item_Index,wfl.SlotNum
) aa 
   left join [WebMES].[dbo].[pln_WorkOrders] workor on aa.customer_code=workor.CustCode and aa.po_number=workor.PONumber 
   group by aa.lot_id, aa.inner_lot,aa.inner_monther_lot,aa.customer_code, aa.wafer_id_read,aa.gpib_bin,aa.customer_notch,
aa.device_name,aa.wafer_id,aa.lot_starttime,aa.hold_count,aa.notch,aa.tester_model,aa.chinese_name,aa.chinese_shortname,
aa.part_num, aa.process_spec,aa.process_revision,aa.worker_order,aa.lot_status,aa.wip_stage,aa.wip_step,workor.PONumber,aa.part_desc, 
aa.map_or_ink,aa.is_otp,aa.is_cop,aa.fab_device,aa.SlotNum ,aa.asy_device, aa.ship_lot,aa.assigned_testers,aa.is_trimed,aa.wafer_sequence,aa.wafer_pcs, 
aa.prober_device,aa.test_gross_die,aa.stand_gross_die,aa.pass_bins,workor.CustLotPostCP, aa.SpecialBins,aa.OSBinsNew,
aa.os_binsraw,aa.wf_size,aa. index_x,aa. index_y,aa.Item_Index,aa.slot) wftotl left join
(select ItemOwner, isnull(max (case when flex.ItemName='PE_Owner'  then flex.ItemValue1  end ),'NA') pe_owner ,
 isnull(max(case when flex.ItemName='Tester_Software_Revision'  then flex.ItemValue1  end ),'NA') tester_SoftWare_revision, 
  isnull(max(case when flex.ItemName='TesterModel'  then flex.ItemValue1  end ),'NA') Tester_Model, 
 isnull( max(case when flex.ItemName='LoadFile'  then flex.ItemValue1  end ),'NA') load_file,
 isnull(max(case when flex.ItemName='Cust_TestSpec'  then flex.ItemValue1  end ),'NA') customer_tester_spec, 
 isnull(max(case when flex.ItemName='Map_Reference'  then flex.ItemValue1  end ),'NA') map_reference,
 isnull(max(case when flex.ItemName='Site-Site'  then flex.ItemValue1  end ),'NA') site_to_site,
 isnull(max(case when flex.ItemName='Continuous_Fail'  then flex.ItemValue1  end ),'NA') continue_fail,
 isnull(max(case when flex.ItemName='ProberCard'  then flex.ItemValue1  end ),'NA') prober_card_id,
 isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') stop_yield,

isnull(max(case when flex.ItemName='Major_Fail'  then flex.ItemValue1  end ),'NA')  major_fail,
isnull(max(case when flex.ItemName='TestTime/Pcs'  then flex.ItemValue1  end ),'NA')  theory_test_time,
--isnull(max(case when flex.ItemName='WaferID_read'  then flex.ItemValue1  end ),'NA') wafer_id_read,
--isnull(max(case when flex.ItemName='Wafer_Sequence'  then flex.ItemValue1  end ),'1-25')  wafer_sequence,
--isnull(max(case when flex.ItemName='GPIB_Bin'  then flex.ItemValue1  end ),'NA') gpib_bin,
isnull(max(case when flex.ItemName='Special_Bin'  then flex.ItemValue1  end ),'NA') special_bins
	from [WebMES].[dbo].[pdm_FlexibleItems] flex
	where flex.Flag=1  and ItemName in ('PE_Owner','Tester_Software_Revision','TesterModel',
	'LoadFile','Cust_TestSpec','Map_Reference','Site-Site','Continuous_Fail',
    'ProberCard','StopYield','Major_Fail','TestTime/Pcs','WaferID_read','Wafer_Sequence','GPIB_Bin','Special_Bin')
	group by ItemOwner) flexconf on  (wftotl.process_spec+':'+ CAST(wftotl.process_revision as nvarchar(10)))= flexconf.ItemOwner
	left join
	( SELECT wfl.WaferID,isnull(max(case when (flwsq.Sites is null or flwsq.Sites='') then 'NA' else flwsq.Sites end ),'NA') Sites,
			isnull(max(case when yieldcont.ControlItem='[By Lot Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10))
	+yieldcont.ControlUOM  end ) ,'NA')+'|'+ isnull(max(case when yieldcont.ControlItem='[By Wafer Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10))+yieldcont.ControlUOM 
	 end ),'NA') controlspec 
	 FROM [WebMES].[dbo].[wip_LotWaferIDs] wfl,[WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[pdm_ProcessFlows] procflow,
	 [WebMES].[dbo].[pdm_ProcessFlowSequence] flwsq, [WebMES].[dbo].[pdm_ProcessYieldControl] yieldcont where wfl.LotNum=wplist.LotNum and 
	 wplist.ProcessFlow=procflow.ProcessFlowName   and flwsq.Sites is not null and flwsq.Sites <>''
	 and flwsq.isActive=1 and flwsq.FlowIndex=procflow.Item_Index
     and wplist.ProcessRevision=procflow.Revision  --and wplist.LotStatus>0 
	 and procflow.Item_Index=yieldcont.FlowIndex and yieldcont.IsActive=1 and procflow.isActive=1
	 and  WaferID=@waferid and CPx=@cpstep
     and ControlItem in ('[By Wafer Yield]','[By Lot Yield]') group by wfl.WaferID) wafspec on wftotl.wafer_id=wafspec.WaferID
	 left join
	 (  select @waferid WaferID ,isnull(max(case when ((Yieldcon='') or (Yieldcon=null) ) then 'NA'  else Yieldcon end ),'NA') Yieldcon from 
  (select   isnull(isnull(max(case when cpstep='CP1'  then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP2' then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP3' then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP4'  then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP5'  then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP6'  then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP7'  then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP8'  then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP9'  then cpstep+'&'+Yield+';' end ),'')+
  isnull(max(case when cpstep='CP10'  then cpstep+'&'+Yield+';' end ),''),'NA')
 Yieldcon from (select WaferID,CPStep cpstep,cast(MAX(WaferYield)as varchar(10))+'%' Yield 
  from   [WebMES].[dbo].[wip_BinSummary] where  WaferID=@waferid and CPStep <>@cpstep
  group by WaferID,CPStep) xx group by WaferID) aa ) yieldinfo on yieldinfo.WaferID= wftotl.wafer_id
  left join 
	 ( select  FlowIndex,( case when substring(shortflow,1,1)='-'  then substring(shortflow,2,len(shortflow)-1)  when
   substring(shortflow,len(shortflow)-1,1)='-'  then substring(shortflow,1,LEN(shortflow)-1) else shortflow end ) shortflowid from
  (select FlowIndex, isnull(max(case when StepSequence=100  then StepCode end ),'')+isnull(max(case when StepSequence=200  then '-' +StepCode end ),'')+
  isnull(max(case when StepSequence=300  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=400  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=500  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=600  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=700  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=800  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=900  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1000  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=1100  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1200  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=1300  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1400  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=1500  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1600  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=1700  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1800  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=1900  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=2000  then '-' +[StepCode] end ),'')+
  isnull(max(case when StepSequence=2100  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=2200  then '-' +[StepCode] end ),'') shortflow
  from( select FlowIndex, StepCode,max(StepSequence) StepSequence
   from ( select [FlowIndex] FlowIndex, substring([StepCode],1,3) StepCode,max([StepSequence]) StepSequence
  from [WebMES].[dbo].[pdm_ProcessFlowSequence] where isActive=1
  group by [FlowIndex], StepCode ) aa  group by FlowIndex, StepCode ) x
  group by FlowIndex ) flowd) prosque on  prosque.FlowIndex=wftotl.Item_Index
  left join
  (select top 1 wfl.WaferLot WaferLot,recp.[PartNumber],[MachineID] testerid,[LinkedMachine] proberid ,[LinkedMachine2] cardid ,[RecipeID] testerprogram,max(AllcpProcess) AllcpProcess
  from ( SELECT  wip_LotWaferIDs.LotNum [LotNum], wip_LotHistory.PartNumber [PartNumber], wip_LotHistory.MachineID [MachineID], 
        wip_LotHistory.LinkedMachine [LinkedMachine], wip_LotHistory.LinkedMachine2 [LinkedMachine2] ,[RecipeID]
                FROM wip_LotWaferIDs INNER JOIN wip_LotHistory ON wip_LotWaferIDs.LotNum = wip_LotHistory.LotNum 
                WHERE (wip_LotWaferIDs.WaferID=@waferid) AND (wip_LotHistory.FromStepCode LIKE @cpstep+'%') 
                    AND (wip_LotHistory.TxnAction IN ('LotTrackIn', 'LotTrackOut','[LotTrackIn]','[LotTrackOut]')) 
					and wip_LotHistory.TxnTime in (SELECT max(wip_LotHistory.TxnTime) txttime
                FROM wip_LotWaferIDs INNER JOIN wip_LotHistory ON wip_LotWaferIDs.LotNum = wip_LotHistory.LotNum 
                WHERE (wip_LotWaferIDs.WaferID=@waferid) AND (wip_LotHistory.FromStepCode LIKE 'CP%T0') 
                    AND (wip_LotHistory.TxnAction IN ('LotTrackIn', 'LotTrackOut','[LotTrackIn]','[LotTrackOut]')) 
					group by wip_LotWaferIDs.LotNum, wip_LotHistory.PartNumber)  ) recp,
(select  [LotNum] ,[PartNumber],  isnull(max(case when CHARINDEX('CP1',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP2',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP3',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP4',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP5',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP6',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP7',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP8',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP9',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP10',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
  isnull(max(case when CHARINDEX('CP11',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'') AllcpProcess
  FROM [WebMES].[dbo].[wip_LotHistory] where TxnAction like '%trackin%' and  CHARINDEX('CP',FromStepCode)>0
  group by [LotNum] ,[PartNumber]) allcpp, [WebMES].[dbo].[wip_LotWaferIDs] wfl
  where recp.[LotNum]=allcpp.LotNum and recp.[PartNumber]=allcpp.PartNumber and recp.[LotNum]=wfl.LotNum
  and wfl.WaferID=@waferid group by wfl.WaferLot,recp.[PartNumber],[MachineID],[LinkedMachine] ,[LinkedMachine2] ,[RecipeID]) recpid
 on recpid.WaferLot=wftotl.lot_id and prosque.FlowIndex=wftotl.Item_Index;
go

