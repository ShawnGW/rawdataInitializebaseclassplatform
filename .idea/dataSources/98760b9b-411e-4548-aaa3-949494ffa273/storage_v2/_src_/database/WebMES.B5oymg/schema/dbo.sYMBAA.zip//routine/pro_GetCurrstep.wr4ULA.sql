CREATE   procedure [dbo].[pro_GetCurrstep] 
@waferid varchar(50)
as

  select isnull(max(case when ((StepCode='') or (StepCode=null) ) then 'NA'  else StepCode end),'NA') cpstep  from 
  (SELECT  top 1  substring(wip_LotHistory.FromStepCode,1,3) StepCode, max(wip_LotHistory.TxnTime) TxnTime
FROM   [WebMES].[dbo].wip_LotWaferIDs INNER JOIN [WebMES].[dbo].wip_LotHistory ON wip_LotWaferIDs.LotNum = wip_LotHistory.LotNum
WHERE  (wip_LotWaferIDs.WaferID = @waferid) AND (wip_LotHistory.TxnAction = 'LotTrackIn') 
AND (wip_LotHistory.FromStepCode LIKE 'CP%T0')
group by substring(wip_LotHistory.FromStepCode,1,3)
ORDER BY  TxnTime DESC) aa
go

