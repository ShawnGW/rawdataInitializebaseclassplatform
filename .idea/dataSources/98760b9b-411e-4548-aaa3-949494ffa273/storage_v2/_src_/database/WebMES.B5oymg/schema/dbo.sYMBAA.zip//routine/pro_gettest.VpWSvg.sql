CREATE procedure [dbo].[pro_gettest]
@lotid varchar(50),
@sequence varchar(50)output ,
@read_type varchar(50) output,
@gpib_bin varchar(50) output
as
 begin
	select  @sequence=sequence,@read_type=read_type,@gpib_bin=gpib_bin
	from (select isnull( c.Wafer_Sequence,'1-25')  sequence,a.read_type,(case when (b.gpib_bin is null or b.gpib_bin ='' or b.gpib_bin ='NA' )  then 'NA' else SUBSTRING(b.gpib_bin,1,1) end) gpib_bin
		from  (SELECT    top 1 isnull(max(case when  ((flex1.ItemValue1='') or (flex1.ItemValue1=null) ) then 'OCR'  else flex1.ItemValue1  end),'OCR')read_type
  FROM [WebMES].[dbo].[pdm_FlexibleItems] flex1, (select ProcessFlow+':'+ CAST(ProcessRevision as nvarchar(10)) process,WaferSequence 
  from [WebMES].[dbo].[wip_LotList]  where CustLotNum = @lotid   and ProcessFlow not like '%DEFAULT%' ) wplist
   where flex1.ItemName='WaferID_read' and wplist.process=flex1.ItemOwner  
    and flex1.Flag=1 ) a,
	(SELECT   top 1 isnull(max(case when  ((flex1.ItemValue1='') or (flex1.ItemValue1=null) ) then '0'  else flex1.ItemValue1  end),'0')  gpib_bin
  FROM [WebMES].[dbo].[pdm_FlexibleItems] flex1, (select ProcessFlow+':'+ CAST(ProcessRevision as nvarchar(10)) process,WaferSequence 
  from [WebMES].[dbo].[wip_LotList]  where CustLotNum = @lotid  and ProcessFlow not like '%DEFAULT%' ) wplist
   where flex1.ItemName='GPIB_Bin' and wplist.process=flex1.ItemOwner  
    and flex1.Flag=1 ) b,
	(SELECT top 1  WaferSequence  Wafer_Sequence
  from [WebMES].[dbo].[wip_LotList]  where CustLotNum = @lotid   and ProcessFlow not like '%DEFAULT%')c) aa
  if (( @sequence is null)or (@sequence=''))
	set @sequence='1-25';
  if (( @read_type is null)or (@read_type=''))
	set @read_type='OCR';
  if (( @gpib_bin is null)or (@gpib_bin=''))
	set @gpib_bin='0';
  end;
go

