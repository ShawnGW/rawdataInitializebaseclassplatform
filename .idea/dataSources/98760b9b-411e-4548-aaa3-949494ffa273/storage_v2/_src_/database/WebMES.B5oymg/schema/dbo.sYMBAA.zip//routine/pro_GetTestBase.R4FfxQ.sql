CREATE   procedure [dbo].[pro_GetTestBase]
@waferid varchar(50),
@cpstep varchar(50)
as

  select top 1  isnull(max(case when ( seque.TestBase  is null or  seque.TestBase  ='' )  then 'Full-Test' else seque.TestBase  end ),'Full-Test') test_base from 
 [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
[WebMES].[dbo].[pdm_ProcessFlows] procflow
 where wfl.WaferID=@waferid   and wfl.LotNum=wplist.LotNum and LotCat<>'I' and LotCat<>'R' 
 and wplist.LotStatus>0  and wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index
 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and seque.StepCode like @cpstep+'%T0';
go

