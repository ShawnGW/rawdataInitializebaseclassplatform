CREATE   procedure [dbo].[pro_getSlotAndSequence]
@lotid varchar(50)
as

     select top 1 sequence,read_type, gpib_bin from (
  	select isnull( WaferSequence,'1-25')   sequence,
	 isnull(max(case when  ((prdevic.waferRead='') or (prdevic.waferRead=null) ) then 'OCR'  else upper(prdevic.waferRead)  end),'OCR') read_type,
	(case when (prdevic.GbibBin is null or prdevic.GbibBin ='' or prdevic.GbibBin='NA' )  then 'NA' else SUBSTRING(prdevic.GbibBin,1,1) end)  gpib_bin
	,max(seque.SetTime) SetTime
		 from [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
		 [WebMES].[dbo].[pdm_ProcessFlows] procflow,[WebMES].[dbo].[pdm_ProberDevice] prdevic
	 where LotCat<>'I' and LotCat<>'R' and seque.OSBins <>'' and wplist.LotStatus>0 and 
	  wplist.CustLotNum = @lotid  and wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index
	 and prdevic.isActive=1 and  seque.ProberDevice=prdevic.ProberDeviceName and prdevic.IsDefault=1
	 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 
	 group by prdevic.GbibBin,prdevic.waferRead, WaferSequence,seque.SetTime  ) aa

go

