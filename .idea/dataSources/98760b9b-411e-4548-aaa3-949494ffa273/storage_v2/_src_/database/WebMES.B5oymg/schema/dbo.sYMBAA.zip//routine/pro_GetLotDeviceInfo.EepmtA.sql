CREATE   procedure [dbo].[pro_GetLotDeviceInfo]
@lot varchar(50)
as
   select  CustCode,CustPart, Lot from 
     (select top 1 CustCode,CustPart, wfd.WaferLot Lot ,max(wfl.CreateTime) CreateTime
	 from  [WebMES].[dbo].wip_LotList wfl,
  [WebMES].[dbo].[wip_LotWaferIDs] wfd
   where wfl.LotNum=wfd.LotNum and wfd.WaferLot=@lot group by CustCode,CustPart, wfd.WaferLot
   order by CreateTime desc) aa ;
go

