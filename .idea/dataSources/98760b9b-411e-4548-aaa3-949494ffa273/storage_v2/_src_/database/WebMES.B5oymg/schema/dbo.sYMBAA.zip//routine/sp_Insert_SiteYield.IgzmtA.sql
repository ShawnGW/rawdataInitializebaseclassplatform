Create proc sp_Insert_SiteYield
     @siteinfo varchar(max),
	 @inserrtn varchar(10) output
as
  
begin
    delete  [WebMES].[dbo].[wip_SiteToSiteYield] where ([WaferLot]+[WaferID] +[CPStep]) in (
      select (max(case when ( Name ='lot' )  then StringValue  end )+
             max(case when ( Name ='waferId' )  then StringValue  end ) +
             max(case when ( Name ='cpStep' )  then StringValue  end ) ) info
        from  [VTEST].[dbo].[parseJSON]
           (@siteinfo))
       set @inserrtn='Del'   
 end
 begin
  insert into [WebMES].[dbo].[wip_SiteToSiteYield] ( [WaferLot],[WaferID] ,[SiteID] ,[CPStep] ,[PassYield] ,[OSYield] ,[SetTime])
     select lotinfo.lot_id WaferLot,lotinfo.Wafer_No WaferID,siteifno.NAME SiteID, lotinfo.CP_Step CPStep,siteifno.Passbin PassYield,siteifno.OSbin OSYield,Getdate() SetTime from 
     (select  max(case when ( Name ='lot' )  then StringValue  end ) lot_id,
              max(case when ( Name ='cpStep' )  then StringValue  end ) CP_Step,
              max(case when ( Name ='waferId' )  then StringValue  end ) Wafer_No
         from  [VTEST].[dbo].[parseJSON]
          (@siteinfo) ) lotinfo,
          (select NAME,max(LEFT(StringValue,CHARINDEX(',',StringValue)-1)) Passbin,max(substring(StringValue,charindex(',',StringValue)+1,len(StringValue)-charindex(',',StringValue))) OSbin
         from  [VTEST].[dbo].[parseJSON]
          (@siteinfo) 
          where parent_ID=1 group by NAME) siteifno
      set @inserrtn='OK'  
 end
go

