CREATE   procedure [dbo].[pro_GetWaferInfo]
@waferid varchar(50),
@cpstep varchar(50)
as

begin

	select top 1 nine.lot_id, fir.inner_lot,nine.inner_monther_lot,eight.customer_code, 
 nine.device_name,nine.wafer_id,nine.lot_starttime,six.pe_owner,six.tester_SoftWare_revision,six.tester_model,five.chinese_name,five.chinese_shortname,
isnull( nine.part_num,'NA') part_num, isnull( nine.process_spec,'NA') process_spec,isnull( nine.process_revision,'NA') process_revision,
isnull( nine.worker_order,'NA') worker_order,isnull( nine.lot_status,'NA') lot_status,isnull(nine.wip_stage,'NA')  wip_stage,
isnull( nine.wip_step,'NA') wip_step,  isnull( nine.po_number,'NA')  po_number  ,eight.customer_to_customer_po_number,isnull(five.part_desc,'NA') part_desc,
five.map_or_ink,nine.is_otp ,nine.is_cop,five.fab_device,five.asy_device, 
eight.ship_lot,five.assigned_testers ,nine.is_trimed,
isnull(six.load_file,'NA') load_file,isnull(six.customer_tester_spec,'NA') customer_tester_spec, isnull(six.map_reference,'NA') map_reference,
isnull(nine.process_short_flow ,'NA') process_short_flow,
nine.wafer_pcs, isnull(case when (nine.sites is null or nine.sites='') then four.sites else nine.sites end ,'NA')  sites, isnull( six.site_to_site,'NA') site_to_site,isnull(six.continue_fail,'NA') continue_fail,
isnull(nine.prober_device,'NA')  prober_device, 'NA' operator, isnull( Fir.tester_program,'NA') tester_program, isnull(Senc.all_cp_programs,'NA') all_cp_programs,
isnull(Fir.tester_id,'NA')  tester_id,
isnull( Fir.prober_id,'NA')  prober_id,isnull( Fir.prober_card_id,'NA') prober_card_id, 'NA' cp_process, nine.hold_count, 'NA' test_start_time,'NA' test_end_time,
nine.test_gross_die,nine.stand_gross_die,'NA' gross_die,'NA' pass_die,'NA' fail_die, 'NA' wafer_yield,
 isnull(case when (six.stop_yieldtmp is null or six.stop_yieldtmp='') then four2.stop_yieldother else six.stop_yieldtmp end ,'NA')  stop_yield,
isnull(six.major_fail,'NA') major_fail,isnull(four.process_yield,'NA|NA') process_yield,isnull(Thrid.cp_yield,'NA' ) cp_yield,isnull(nine.pass_bins,'NA' ) pass_bins,
nine.os_bins os_bins,
(case when (nine.special_bins is null or nine.special_bins ='' or nine.special_bins ='NA' )  then six.special_binscon else nine.special_bins end) special_bins,
(case when (six.theory_test_time is null or six.theory_test_time ='' or six.theory_test_time ='NA' )  then 'NA'  when CHARINDEX('CP',six.theory_test_time )<=0 
	 then six.theory_test_time  when CHARINDEX(@cpstep,six.theory_test_time )<=0 then 'NA' else
	(SUBSTRING(six.theory_test_time ,CHARINDEX(@cpstep,six.theory_test_time )+4,4 )) end )   theory_test_time,
'NA' retest_rate, 'NA' data_base,'NA' test_time,nine.wafer_id_read,nine.wafer_sequence,nine.wf_size,nine.index_x,nine.index_y,
'NA' map_cols,'NA' map_rows,(case when (nine.gpib_bin is null or nine.gpib_bin ='' or nine.gpib_bin ='NA' )  then 'NA' else SUBSTRING(nine.gpib_bin,1,1) end) gpib_bin,
nine.notch, nine.customer_notch  customer_notch,nine.slot,
(case when nine.wafer_sequence='25-1'then 26-nine.slot else nine.slot end) right_id,
'NA' minx,'NA' miny,'NA' maxx ,'NA' maxy,'NA' test_die_minx,'NA' test_die_miny, 'NA' test_die_maxx,'NA' test_die_maxy


	--Step 1 获取该片wafer在该道CP step的 LotNum,PartNumber,MachineID,LinkedMachine,Cardid,RecipeID
	--input waferid,cpstep
	--output inner_lot,part_num,tester_id, prober_id, prober_card_id,tester_program
	from  (SELECT top 1 wlf.LotNum inner_lot, his.PartNumber part_num, his.MachineID tester_id, 
	   his.LinkedMachine prober_id, his.LinkedMachine2 prober_card_id ,[RecipeID] tester_program,his.txntime
		 FROM [WebMES].[dbo].wip_LotWaferIDs wlf INNER JOIN [WebMES].[dbo].wip_LotHistory his ON wlf.LotNum = his.LotNum 
		   WHERE (wlf.WaferID=@waferid ) AND (his.FromStepCode LIKE @cpstep+'%') 
			 AND (his.TxnAction IN ('LotTrackIn', 'LotTrackOut','[LotTrackIn]','[LotTrackOut]')) and his.toqty>0 
			 order by his.txntime desc) Fir,

	--Step2 获取该片wafer经过的所有CP Process 
	--input waferid
	--output all_cp_programs
	(select isnull(max(case when CHARINDEX('CP1',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP2',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP3',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP4',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP5',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP6',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP7',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP8',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP9',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP10',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('CP11',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'') all_cp_programs
	  FROM [WebMES].[dbo].[wip_LotHistory] his where TxnAction like '%trackin%' and  CHARINDEX('CP',FromStepCode)>0 and LotNum in 
	  ( select lotnum from [WebMES].[dbo].[wip_LotWaferIDs] where WaferID=@waferid )) Senc,
  
	  --Step3 获取该片wafer经过的所有CP Yield
	--input waferid, cpstep
	--output cp_yield
	  (select @waferid  wafer_id ,isnull(max(case when ((Yieldcon='') or (Yieldcon=null) ) then 'NA'  
	  else SUBSTRING(Yieldcon,1,Len(Yieldcon)-1)  end ),'NA') cp_yield from 
	  (select   isnull(isnull(max(case when cpstep='CP1'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP2' then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP3' then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP4'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP5'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP6'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP7'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP8'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP9'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='CP10'  then cpstep+'&'+Yield+';' end ),''),'NA')
	 Yieldcon from (select WaferID,CPStep cpstep,cast(MAX(WaferYield)as varchar(10))+'%' Yield 
	  from   [WebMES].[dbo].[wip_BinSummary] where  WaferID=@waferid  and CPStep <>@cpstep
	  group by WaferID,CPStep) xx group by WaferID) cpyield ) Thrid ,

  
	--Step4 获取该片wafer经过的所有CP Yield
	--input waferid, cpstep
	--output sites,process_yield

	(select @waferid  WaferID,isnull(max(case when (xx.sites is null or xx.sites='') then 'NA' else xx.sites end ),'NA') sites,
	  isnull(max(case when (xx.process_yield is null or xx.process_yield='') then 'NA|NA' else xx.process_yield end ),'NA|NA') process_yield
	      from ( SELECT   yy.WaferID,isnull(max(case when (yy.Sites is null or yy.Sites='') then 'NA' else yy.Sites end ),'NA') sites,
		isnull(max(case when  lotyield2='NA' then lotyield1 else lotyield2 end ) ,'NA')+'|'+ isnull(max(case when  wafyield2='NA' then wafyield1 else wafyield2 end ) ,'NA')
				 process_yield 
		 from (SELECT   wfl.WaferID,isnull(max(case when (flwsq.Sites is null or flwsq.Sites='') then 'NA' else flwsq.Sites end ),'NA') sites,
		 isnull(max(case when yieldcont.ControlItem='[By Wafer Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') wafyield1 ,
		 isnull(max(case when yieldcont.ControlItem='[By Wafer Final Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') wafyield2,
		 isnull(max(case when yieldcont.ControlItem='[By Lot Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') lotyield1,
		 isnull(max(case when yieldcont.ControlItem='[By Lot Final Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') lotyield2
		 FROM [WebMES].[dbo].[wip_LotWaferIDs] wfl,[WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[pdm_ProcessFlows] procflow,
		 [WebMES].[dbo].[pdm_ProcessFlowSequence] flwsq, [WebMES].[dbo].[pdm_ProcessYieldControl] yieldcont where wfl.LotNum=wplist.LotNum and 
		 wplist.ProcessFlow=procflow.ProcessFlowName   and flwsq.Sites is not null and flwsq.Sites <>''
		 and flwsq.isActive=1 and flwsq.FlowIndex=procflow.Item_Index
		 and wplist.ProcessRevision=procflow.Revision and wplist.lotstatus>0 and yieldcont.ControlMethod in ('<','<=')
		 and procflow.Item_Index=yieldcont.FlowIndex and yieldcont.IsActive=1 and procflow.isActive=1
		 and  WaferID=@waferid  and CPx=@cpstep and flwsq.stepcode  like @cpstep+'%'
		 and ControlItem in ('[By Wafer Yield]','[By Lot Yield]','[By Wafer Final Yield]','[By Lot Final Yield]') group by wfl.WaferID) yy  group by WaferID ) xx ) four,

	--Step4_2 获取该片wafer经过的所有stopYield
	--input waferid, cpstep
	--output sites,process_yield
	 ( SELECT isnull(max(case when stop_yield1='NA'  then  stop_yield2 else stop_yield1 end ),'NA') stop_yieldother from 
	  (  SELECT wfl.WaferID,
		 isnull(max(case when yieldcont.ControlItem='[By Wafer Yield]'  then  CAST(yieldcont.ControlLimit-5 as nvarchar(10)) end ),'NA') stop_yield1 ,
		 isnull(max(case when yieldcont.ControlItem='[By Lot Yield]'  then  CAST(yieldcont.ControlLimit-5 as nvarchar(10)) end ),'NA') stop_yield2
		 FROM [WebMES].[dbo].[wip_LotWaferIDs] wfl,[WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[pdm_ProcessFlows] procflow,
		 [WebMES].[dbo].[pdm_ProcessFlowSequence] flwsq, [WebMES].[dbo].[pdm_ProcessYieldControl] yieldcont where wfl.LotNum=wplist.LotNum and 
		 wplist.ProcessFlow=procflow.ProcessFlowName   and flwsq.Sites is not null and flwsq.Sites <>''
		 and flwsq.isActive=1 and flwsq.FlowIndex=procflow.Item_Index
		 and wplist.ProcessRevision=procflow.Revision and wplist.lotstatus>0 and yieldcont.ControlMethod in ('<','<=')
		 and procflow.Item_Index=yieldcont.FlowIndex and yieldcont.IsActive=1 and procflow.isActive=1
		 and  WaferID=@waferid  and CPx=@cpstep and flwsq.stepcode  like @cpstep+'%'
		 and ControlItem in ('[By Wafer Yield]','[By Lot Yield]') group by wfl.WaferID)aa ) four2,

	--Step5 获取该片wafer prod配置信息
	--input waferid, cpstep
	--output chinese_name,chinese_shortname,map_or_ink,fab_device,asy_device,assigned_testers,os_binsraw

	  (select top 1 isnull(max(case when ( cust.CustCName  is null or  cust.CustCName  ='' )  then 'NA' else  cust.CustCName  end ),'NA') chinese_name,
	 isnull(max(case when ( cust.ShortName  is null or  cust.ShortName  ='' )  then 'NA' else  cust.ShortName  end ),'NA') chinese_shortname,
	isnull(max(case when ( pn.PartDescription is null or  pn.PartDescription  ='' )  then 'NA' else pn.PartDescription  end ),'NA') part_desc, 
	isnull(max(case when ( pn.MapOrInk  is null or  pn.MapOrInk ='' )  then 'NA' else  pn.MapOrInk  end ),'NA') map_or_ink,
	isnull(max(case when ( pn.FabDevice  is null or  pn.FabDevice  ='' )  then 'NA' else  pn.FabDevice  end ),'NA') fab_device,
	isnull(max(case when ( pn.AsyDevice  is null or  pn.AsyDevice  ='' )  then 'NA' else  pn.AsyDevice  end ),'NA') asy_device, 
	isnull(max(case when ( pn.AssignedTesters  is null or  pn.AssignedTesters  ='' )  then 'NA' else  pn.AssignedTesters  end ),'NA') assigned_testers,
	 isnull(max(case when ( pn.CpxOsBins  is null or  pn.CpxOsBins  ='' )  then pn.OpenShortBinCode else  pn.CpxOsBins  end ),'NA') os_binsraw
	 from [WebMES].[dbo].pdm_Products pn ,[WebMES].[dbo].[pdm_Customers] cust,[WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl
	where wfl.WaferID=@waferid   and pn.CustCode=cust.CustCode
	 and cust.isActive=1 and  pn.isActive = 1 and pn.PartNumber=wplist.PartNumber  
	 and wfl.LotNum=wplist.LotNum and LotCat<>'I' and LotCat<>'R'-- and (pn.OpenShortBinCode like @cpstep+'%' or pn.CpxOsBins  like @cpstep+'%')
	 and wplist.LotStatus>0 
	 group by pn.PartDescription) five,


	 --Step6 获取该片wafer process下的MES配置参数
	--input process_spec process_revision
	--output ItemOwner,pe_owner,tester_SoftWare_revision, tester_model, load_file,customer_tester_spec, map_reference,site_to_site,
			--continue_fail,stop_yield,major_fail,theory_test_time, special_binscon

	 (select ItemOwner, isnull(max (case when flex.ItemName='PE_Owner'  then flex.ItemValue1  end ),'NA') pe_owner ,
	 isnull(max(case when flex.ItemName='Tester_Software_Revision'  then flex.ItemValue1  end ),'NA') tester_SoftWare_revision, 
	  isnull(max(case when flex.ItemName='TesterModel'  then flex.ItemValue1  end ),'NA') tester_model, 
	 isnull( max(case when flex.ItemName='LoadFile'  then flex.ItemValue1  end ),'NA') load_file,
	 isnull(max(case when flex.ItemName='Cust_TestSpec'  then flex.ItemValue1  end ),'NA') customer_tester_spec, 
	 isnull(max(case when flex.ItemName='Map_Reference'  then flex.ItemValue1  end ),'NA') map_reference,
	 isnull(max(case when flex.ItemName='Site-Site'  then flex.ItemValue1  end ),'NA') site_to_site,
	 isnull(max(case when flex.ItemName='Continuous_Fail'  then flex.ItemValue1  end ),'NA') continue_fail,
	 --此次有逻辑,如果找不到,找hold limit
  
	 (case when (isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') is null or isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') ='') 
	  then 'NA'  when CHARINDEX('CP',isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA'))<=0 
	  then isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA')
	  when CHARINDEX(@cpstep,isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') )<=0 then 'NA' else
	(SUBSTRING(isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') ,CHARINDEX(@cpstep,isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') )+4,2 )) end ) stop_yieldtmp,

	isnull(max(case when flex.ItemName='Major_Fail'  then flex.ItemValue1  end ),'NA')  major_fail,
	isnull(max(case when flex.ItemName='TestTime/Pcs'  then flex.ItemValue1  end ),'NA')  theory_test_time,
	isnull(max(case when flex.ItemName='Special_Bin'  then flex.ItemValue1  end ),'NA') special_binscon
	from [WebMES].[dbo].[pdm_FlexibleItems] flex,
	( select  wplist.ProcessFlow process_spec,wplist.ProcessRevision process_revision from 
	 [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
	[WebMES].[dbo].[pdm_ProcessFlows] procflow
	 where wfl.WaferID=@waferid   and wfl.LotNum=wplist.LotNum and LotCat<>'I' and LotCat<>'R' 
	 and wplist.LotStatus>0  and wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index
	 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and seque.StepCode like @cpstep+'%R0' ) wftotl
	where flex.Flag=1  and ItemName in ('PE_Owner','Tester_Software_Revision','TesterModel',
		'LoadFile','Cust_TestSpec','Map_Reference','Site-Site','Continuous_Fail',
		'ProberCard','StopYield','Major_Fail','TestTime/Pcs','WaferID_read','Wafer_Sequence','GPIB_Bin','Special_Bin')
	and ItemOwner= (wftotl.process_spec+':'+ CAST(wftotl.process_revision as nvarchar(10)))	group by ItemOwner ) six,
	--and ItemOwner= 'SFD_CFM347U04-00100:7'	group by ItemOwner


	-- --Step7 获取该片wafer process short flow
	----input procesflowindex
	----output process_short_flow

	--(select  FlowIndex,( case when substring(shortflow,1,1)='-'  then substring(shortflow,2,len(shortflow)-1)  when
	--   substring(shortflow,len(shortflow)-1,1)='-'  then substring(shortflow,1,LEN(shortflow)-1) else shortflow end ) process_short_flow from
	--  (select FlowIndex, isnull(max(case when StepSequence=100  then StepCode end ),'')+isnull(max(case when StepSequence=200  then '-' +StepCode end ),'')+
	--  isnull(max(case when StepSequence=300  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=400  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=500  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=600  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=700  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=800  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=900  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1000  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=1100  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1200  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=1300  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1400  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=1500  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1600  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=1700  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=1800  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=1900  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=2000  then '-' +[StepCode] end ),'')+
	--  isnull(max(case when StepSequence=2100  then  '-' +  StepCode end ),'')+isnull(max(case when StepSequence=2200  then '-' +[StepCode] end ),'') shortflow
	--  from( select FlowIndex, StepCode,max(StepSequence) StepSequence
	--   from ( select [FlowIndex] FlowIndex, substring([StepCode],1,3) StepCode,max([StepSequence]) StepSequence
	--  from [WebMES].[dbo].[pdm_ProcessFlowSequence] where isActive=1
	--  group by [FlowIndex], StepCode ) aa  group by FlowIndex, StepCode ) x
	--  group by FlowIndex ) flowd where FlowIndex= (select procflow.Item_Index from 
	-- [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
	--[WebMES].[dbo].[pdm_ProcessFlows] procflow,[WebMES].[dbo].[pdm_ProberDevice] prdevic
	-- where wfl.WaferID=@waferid   and wfl.LotNum=wplist.LotNum and LotCat<>'I' and LotCat<>'R' 
	-- and prdevic.isActive=1 and  seque.ProberDevice=prdevic.ProberDeviceName 
	-- and wplist.LotStatus>0  and wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index
	-- and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and seque.StepCode like 'CP3%R0')  ) seven,
 
	 --Step8 获取该片wafer process short flow
	--input waferid
	--output customer_code,ship_lot,customer_to_customer_po_number

	( select customer_code,ship_lot, isnull(max(case when ( CustPO  is null or CustPO  ='' ) 
		then 'NA' else  CustPO  end ),'NA') customer_to_customer_po_number
		from (select top 1 wpl.customer_code, wpl.ship_lot,max(workor.CustCustPO)  CustPO from 
	(SELECT  custcode customer_code,max(wplist.PONumber) PONumber, isnull(max(case when ( CustLotPostCP  is null or CustLotPostCP  ='' ) 
		then wplist.CustLotNum else  CustLotPostCP  end ),'NA')  ship_lot
		FROM [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[wip_LotWaferIDs] wafid
		where WaferID=@waferid  and LotStatus>0 and wplist.LotNum=wafid.LotNum  group by custcode)  wpl
		left join [WebMES].[dbo].[pln_WorkOrders] workor on wpl.customer_code=workor.CustCode and wpl.PONumber=workor.PONumber
		group by wpl.customer_code, wpl.ship_lot)zz group by customer_code,ship_lot  ) eight,

    	


	 --Step9 获取该片wafer process的主要wafer信息
	--input procesflowindex
	--output ***
		(   select top 1  wplist.CustLotNum lot_id, wplist.LotNum inner_lot,wplist.MotherLot inner_monther_lot, wplist.CustPart device_name,
	  wfl.WaferID wafer_id,wplist.WaferSequence wafer_sequence,wplist.PartNumber part_num ,StartTime lot_starttime, wplist.WorkOrder worker_order,
	   wplist.ProcessFlow process_spec,wplist.ProcessRevision process_revision,wplist.LotStatus lot_status, wplist.HoldCount hold_count,
	   wplist.PCS wafer_pcs,procflow.GrossDie stand_gross_die,
	   (case when ( seque.ProberDevice is null or  seque.ProberDevice ='' or seque.ProberDevice ='NA' )  then 'NA'  
	when ((len( seque.ProberDevice)<4)  or (CHARINDEX(@cpstep, seque.ProberDevice )<1 )) then  seque.ProberDevice else 
	(SUBSTRING( SUBSTRING( seque.ProberDevice,CHARINDEX(@cpstep, seque.ProberDevice )+4,len( seque.ProberDevice ) ),1,
	case when CHARINDEX(';',SUBSTRING( seque.ProberDevice ,CHARINDEX(@cpstep, seque.ProberDevice)+4,len( seque.ProberDevice ) ) )>1 then
	CHARINDEX(';',SUBSTRING( seque.ProberDevice ,CHARINDEX(@cpstep, seque.ProberDevice )+4,len( seque.ProberDevice ) ) )-1
	else len(SUBSTRING( seque.ProberDevice ,CHARINDEX(@cpstep, seque.ProberDevice )+4,len( seque.ProberDevice ) ))  end ))
	  end ) prober_device ,
	  isnull((case when ( wplist.WipStage  is null or   wplist.WipStage  ='' )  then 'NA' else   wplist.WipStage  end ),'NA') 	wip_stage, 
	  isnull((case when (wplist.WipStep  is null or  wplist.WipStep  ='' )  then 'NA' else  wplist.WipStep  end ),'NA') wip_step,
	  isnull((case when (wplist.PONumber  is null or  wplist.PONumber  ='' )  then 'NA' else  wplist.PONumber  end ),'NA') po_number ,
	  isnull((case when ( procflow.isTrimed  is null or  procflow.isTrimed  ='' )  then 0 else  procflow.isTrimed  end ),0) is_trimed,
	  isnull((case when ( procflow.isOTP  is null or  procflow.isOTP  ='' )  then 0 else  procflow.isOTP  end ),0) is_otp,
      isnull((case when ( procflow.isCUP  is null or  procflow.isCUP  ='' )  then 0 else  procflow.isCUP  end ),0) is_cop,
	   prdevic.GrossDie test_gross_die,prdevic.WaferNotch notch,prdevic.PassBins  pass_bins,prdevic.SpecialBins  special_bins,
	   prdevic.DieSize_X   index_x,prdevic.DieSize_Y    index_y, prdevic.WaferRead   wafer_id_read,prdevic.GbibBin  gpib_bin,
	   isnull((case when ( procflow.ReportNotch  is null or  procflow.ReportNotch  ='' )  then 'NA' else  procflow.ReportNotch  end ),'NA')  customer_notch,
		procflow.Item_Index,wfl.SlotNum slot,seque.OSBins os_bins, seque.Sites sites,
		procflow.WaferSize wf_size,procflow.WholeFlow3 process_short_flow
		 from [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl ,
		[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,[WebMES].[dbo].[pdm_ProcessFlows] procflow,[WebMES].[dbo].[pdm_ProberDevice] prdevic
	 where wfl.WaferID=@waferid   and wfl.LotNum=wplist.LotNum and LotCat<>'I' and LotCat<>'R' and seque.OSBins <>''
	 and wplist.LotStatus>0 and  wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index
	 and prdevic.isActive=1 and  seque.ProberDevice=prdevic.ProberDeviceName and prdevic.IsDefault=1
	 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and seque.StepCode   like @cpstep+'%' order by StartTime desc  ) nine

end;
go

