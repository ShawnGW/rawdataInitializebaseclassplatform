
CREATE   procedure [dbo].[pro_getWaferid]
@lotid varchar(50),
@slot varchar(50)
as
 select WaferID from (
 select  top 1 WaferID,max(SetTime) SetTimed from [WebMES].[dbo].wip_LotWaferIDs where WaferLot=@lotid  and SlotNum=@slot 
	and (LotNum IN (SELECT LotNum FROM wip_LotList WHERE (LotStatus > 0)))
 group by WaferID order by SetTimed desc )aa
go

