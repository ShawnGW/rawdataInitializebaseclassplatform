Create   procedure [dbo].[pro_GetBinDescInfo]
@waferid varchar(50),
@cpstep varchar(50)
as

  select stuff((select ';'+A.mername from (select aa.SoftBinno+':'+aa.[BinDefinition] mername from 
  (SELECT   CONVERT(nvarchar(100), CAST([SoftBin] AS decimal(11,0))) SoftBinno ,[BinDefinition]
  FROM [WebMES].[dbo].[pdm_SoftBinDefinition] aa,
  (SELECT wp.ProcessFlow,wp.ProcessRevision
  FROM [WebMES].[dbo].[wip_LotWaferIDs] a ,[WebMES].[dbo].wip_LotHistory his ,
    [WebMES].[dbo].wip_LotList wp  where a.WaferID=@waferid
  and a.LotNum=his.LotNum and his.FromStepCode = @cpstep+'T0' 
  and his.TxnAction='LotTrackIn'  and wp.LotNum=his.LotNum) hh
  where aa.[ProcessFlowName]=hh.ProcessFlow and aa.Revision=hh.ProcessRevision
  and CPStep=@cpstep and Flag=1) aa) A FOR xml PATH('')), 1, 1, '') as Descname ;
go

