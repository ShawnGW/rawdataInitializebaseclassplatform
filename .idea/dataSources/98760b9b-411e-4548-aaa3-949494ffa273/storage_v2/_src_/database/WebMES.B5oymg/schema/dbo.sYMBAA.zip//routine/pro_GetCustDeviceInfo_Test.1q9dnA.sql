Create   procedure [dbo].[pro_GetCustDeviceInfo_Test]
@waferid varchar(50),
@cpstep varchar(50)
as

select   CustCode,CustPart,Lot  from 
(select wplist.CustCode CustCode, wplist.CustPart CustPart,wplist.CustLotNum Lot,max(wplist.createtime) createtime from 
[WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl, [WebMES].[dbo].pdm_Products pn ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
[WebMES].[dbo].[pdm_ProcessFlows] procflow,[WebMES].[dbo].[pdm_Customers] cust,[WebMES].[dbo].[pdm_ProberDevice] prdevic,
[WebMES].[dbo].[whm_Inventory] invent,(SELECT  custcode, CustLotPostCP  FROM [WebMES].[dbo].[wip_LotList] where  LotNum in 
  (select LotNum from [WebMES].[dbo].[wip_LotWaferIDs] where 
  settime= (SELECT max(settime) FROM [WebMES].[dbo].[wip_LotWaferIDs] where WaferID=@waferid  group by WaferID))) xx
where wplist.CustLotNum=wfl.[WaferLot] and wfl.WaferID=@waferid
and prdevic.isActive=1 and seque.isActive=1 and  seque.FlowIndex=procflow.Item_Index and seque.ProberDevice=prdevic.ProberDeviceName 
 and wplist.ProcessFlow=procflow.ProcessFlowName and procflow.isActive=1 and wplist.ProcessRevision=procflow.Revision
 and pn.CustCode=cust.CustCode
 and wfl.LotNum=wplist.LotNum and wplist.ProcessFlow=procflow.ProcessFlowName and wplist.ProcessRevision=procflow.Revision  
 and cust.isActive=1 and   invent.PartNumber=wplist.PartNumber and xx.CustCode=pn.CustCode
 and seque.StepCode like @cpstep+'%' and prdevic.IsDefault=1 and seque.OSBins is not null and seque.OSBins <>''
 And wplist.LotStatus in (-8,0,1,8,9,10,99) and  pn.isActive = 1 and pn.PartNumber=wplist.PartNumber  
 and wfl.SetTime in (select max(SetTime) SetTime from [WebMES].[dbo].wip_LotWaferIDs where  WaferID=@waferid  group by WaferID)
 group by wplist.CustCode , wplist.CustPart ,wplist.CustLotNum ) aa
go

