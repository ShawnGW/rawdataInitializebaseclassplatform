
Create proc [dbo].[P_Send_Mail]
@product_id varchar(100), --入参
@lot_id   varchar(100),
@wafer_no   varchar(100),
@tester_id   varchar(100)
as

begin
declare @mailbodystr nvarchar(1000) --得到总记录条数的语句 
declare @mailsubstr nvarchar(1000) --得到总记录条数的语句 
set @mailbodystr='Please pay attention and help to check the Tester:' +@tester_id +' Product:'+ @product_id +' Lot:'+ @lot_id+' Wafer:'+ @wafer_no
set @mailsubstr='Warning Tester:'+ @tester_id +' Product:'+ @product_id +' Lot:'+ @lot_id+' Wafer:'+ @wafer_no
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'SendMail',  --定义好的sql server 邮箱账户名
    @recipients = 'gongqian.yang@v-test.com.cn;vtestpte@v-test.com.cn;',  --需要发送邮件的账号，多个用;间隔，建议通过一个邮件组来管理需要发送的地址
    @body = @mailbodystr,   -- 邮件正文
    @subject = @mailsubstr

end
go

