CREATE   procedure [dbo].[pro_GetCardTouchInfo]

as

  select aa.probercard,bb.Nowdowncunt%300000 td, aa.touchdowncunt td_total,300000-bb.Nowdowncunt%300000 remain_td , 10*300000-aa.touchdowncunt remain_total from
(select probercard,sum(cutp+cutr) touchdowncunt from
(SELECT wfrid.waferid, wfhis.LinkedMachine2 probercard,wftd.cpstep  ,  max(wftd.FirstTestCnt) cutp,max(wftd.RetestCnt) cutr
  FROM [WebMES].[dbo].[wip_WaferTestTime] wftd,[WebMES].[dbo].[wip_LotWaferIDs] wfrid,[WebMES].[dbo].[wip_LotHistory] wfhis
  where wftd.WaferID=wfrid.WaferID and wfrid.LotNum =wfhis.LotNum and wfhis.LinkedMachine2 is not null and fulltrackout=1
  and wfhis.LinkedMachine2<>'' 
  group by wfrid.waferid, wfhis.LinkedMachine2,wftd.cpstep ) aa --where  probercard='MXD8921-PC-04'
  group by probercard ) aa left join
  (select probercard,sum(cutp+cutr) Nowdowncunt from
(SELECT wfrid.waferid, wfhis.LinkedMachine2 probercard,wftd.cpstep  ,  max(wftd.FirstTestCnt) cutp,max(wftd.RetestCnt) cutr
  FROM [WebMES].[dbo].[wip_WaferTestTime] wftd,[WebMES].[dbo].[wip_LotWaferIDs] wfrid,[WebMES].[dbo].[wip_LotHistory] wfhis
  where wftd.WaferID=wfrid.WaferID and wfrid.LotNum =wfhis.LotNum and wfhis.LinkedMachine2 is not null and fulltrackout=1
  and wfhis.LinkedMachine2<>'' --and  txntime>convert(varchar(10),getdate()-100,120)
  group by wfrid.waferid, wfhis.LinkedMachine2,wftd.cpstep ) aa --where  probercard='MXD8921-PC-04'
  group by probercard ) bb
  on aa.probercard=bb.probercard 
union
( select * from
  (select '8625C-B3569-PC-01' probercard,118239%300000 td, 118239 td_total,300000-118239%300000 remain_td , 6*300000-118239 remain_total ) a union
  (select 'MXD8629S-PC-01' probercard,554090%300000 td, 554090 td_total,300000-554090%300000 remain_td , 6*300000-554090 remain_total )  union
  (select 'B3569-X48-PC-01' probercard,1256989%300000 td, 1256989 td_total,300000-1256989%300000 remain_td , 6*300000-1256989 remain_total ) union
  (select 'MXD8631SF-PC-01' probercard,115832%300000 td, 115832 td_total,300000-115832%300000 remain_td , 6*300000-115832 remain_total ) union
  (select 'MXD8631SF-PC-02' probercard,59959%300000 td, 59959 td_total,300000-59959%300000 remain_td , 6*300000-59959 remain_total ) union
  (select 'MXD8011HU-PC-01' probercard,1658693%300000 td, 1658693 td_total,300000-1658693%300000 remain_td , 6*300000-1658693 remain_total ))
    order by aa.probercard
go

