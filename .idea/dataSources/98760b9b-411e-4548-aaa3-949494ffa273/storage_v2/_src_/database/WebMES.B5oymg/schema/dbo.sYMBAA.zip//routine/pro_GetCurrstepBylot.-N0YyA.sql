CREATE   procedure [dbo].[pro_GetCurrstepBylot] 
@lotid varchar(50)
as

 select distinct substring(stepcode,1,3) stepcode, max(lastactiontime) lastime from 
 [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
[WebMES].[dbo].[pdm_ProcessFlows] procflow
 where wfl.WaferLot=@lotid and wfl.LotNum=wplist.LotNum and LotCat<>'I' and LotCat<>'R' 
 and wplist.LotStatus>0  and wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index
 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and  wplist.wipstep like 'CP9%' 
 and wfl.WaferLot not in (SELECT distinct [WaferLot]
  FROM [WebMES].[dbo].[wip_BinSummary] where WaferLot=@lotid and CPStep='CP9')
 group by substring(stepcode,1,3)
go

