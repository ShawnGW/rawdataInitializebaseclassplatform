Create   procedure [dbo].[pro_GetLaststep] 
@waferid varchar(50),
@cpstep varchar(50)
as

 select case when (last_step is null or last_step='') then 'NA' else last_step end cpstep from
(select substring(lsit.steplist,CHARINDEX(@cpstep,lsit.steplist)-4,3) last_step   from (
select isnull(max(case when CHARINDEX('CP1',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP2',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP3',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP4',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP5',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP6',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP7',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP8',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP9',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP10',aa.stepcode)>0  then aa.stepcode+':' end ),'')+
  isnull(max(case when CHARINDEX('CP11',aa.stepcode)>0  then aa.stepcode+':' end ),'') steplist
  from ( select distinct substring(stepcode,1,3) stepcode, max(lastactiontime) lastime from 
 [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
[WebMES].[dbo].[pdm_ProcessFlows] procflow
 where wfl.WaferID=@waferid  and wfl.LotNum=wplist.LotNum and LotCat<>'I' and LotCat<>'R' 
 and wplist.LotStatus>0  and wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index
 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and seque.StepCode like 'CP%' 
 group by substring(stepcode,1,3))aa ) lsit) xx ;
go

