Create   procedure [dbo].[pro_GetBininfo]
@waferid varchar(50)
as

 select pass_bins passbin from (
select wplist.CustLotNum lot_id, wplist.LotNum inner_lot,wplist.MotherLot inner_monther_lot,wplist.CustCode customer_code, 
 wplist.CustPart device_name,wfl.WaferID wafer_id,max(StartTime) lot_starttime,prdevic.WaferNotch notch,
isnull(max(case when ( pn.CpxPassBins  is null or  pn.CpxPassBins   ='' )  then 'CP1:1' else  pn.CpxPassBins  end ),'NA') pass_bins
 from [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].wip_LotWaferIDs wfl, [WebMES].[dbo].pdm_Products pn ,[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
[WebMES].[dbo].[pdm_ProcessFlows] procflow,[WebMES].[dbo].[pdm_Customers] cust,[WebMES].[dbo].[pdm_ProberDevice] prdevic,
[WebMES].[dbo].[whm_Inventory] invent,(SELECT  custcode, CustLotPostCP  FROM [WebMES].[dbo].[wip_LotList] where  LotNum in 
  (select LotNum from [WebMES].[dbo].[wip_LotWaferIDs] where 
  settime= (SELECT max(settime) FROM [WebMES].[dbo].[wip_LotWaferIDs] where WaferID=@waferid  group by WaferID))) xx
where wplist.CustLotNum=wfl.[WaferLot] and wfl.WaferID=@waferid  
and prdevic.isActive=1 and seque.isActive=1 and  seque.FlowIndex=procflow.Item_Index and seque.ProberDevice=prdevic.ProberDeviceName 
 and wplist.ProcessFlow=procflow.ProcessFlowName and procflow.isActive=1 and wplist.ProcessRevision=procflow.Revision
 and pn.CustCode=cust.CustCode
 and wfl.LotNum=wplist.LotNum and wplist.ProcessFlow=procflow.ProcessFlowName and wplist.ProcessRevision=procflow.Revision  
 and cust.isActive=1 and invent.V_LotNum=wplist.CustLotNum and xx.CustCode=pn.CustCode
and  prdevic.IsDefault=1 
 And wplist.LotStatus in (-8,0,1,8,9,10,99) and  pn.isActive = 1 and pn.PartNumber=wplist.PartNumber  
 and wfl.SetTime in (select max(SetTime) SetTime from [WebMES].[dbo].wip_LotWaferIDs where  WaferID=@waferid group by WaferID)
 group by wplist.CustLotNum , wplist.LotNum ,wplist.MotherLot ,wplist.CustCode , wplist.CustPart ,wfl.WaferID ,wplist.WaferSequence,prdevic.WaferNotch) aa
go

