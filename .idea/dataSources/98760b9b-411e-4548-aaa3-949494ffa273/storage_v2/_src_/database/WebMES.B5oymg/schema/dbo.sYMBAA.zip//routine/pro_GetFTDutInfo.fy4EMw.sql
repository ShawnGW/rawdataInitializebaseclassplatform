CREATE  procedure [dbo].[pro_GetFTDutInfo]
@dutno varchar(50),
@ftstep varchar(50)
as

begin

	select top 1 four.LotNum lot_id,nine.inner_monther_lot,eight.customer_code, 
 nine.device_name, 'NA' wafer_id,nine.lot_starttime,six.pe_owner,six.tester_software_revision,six.tester_model,five.chinese_name,five.chinese_shortname,
isnull( nine.part_num,'NA') part_num, isnull( nine.process_spec,'NA') process_spec,isnull( nine.process_revision,'NA') process_revision,
isnull( nine.worker_order,'NA') worker_order,isnull( nine.lot_status,'NA') lot_status,isnull(nine.wip_stage,'NA')  wip_stage,
isnull( nine.wip_step,'NA') wip_step,  isnull( nine.po_number,'NA')  po_number  ,eight.customer_to_customer_po_number,isnull(five.part_desc,'NA') part_desc,
nine.is_otp ,nine.is_cop,five.fab_device,five.asy_device, nine.is_trimed,isnull(six.load_file,'NA') load_file,isnull(six.customer_tester_spec,'NA') customer_tester_spec, 
isnull(nine.process_short_flow ,'NA') process_short_flow,isnull(six.load_bord,'NA') load_bord,'NA' socket_number,
eight.ship_lot,isnull(case when (nine.sites is null or nine.sites='') then four.sites else nine.sites end ,'NA')  sites, isnull( six.site_to_site,'NA') site_to_site,
isnull(six.continue_fail,'NA') continue_fail,isnull(nine.handel_device,'NA')  handel_device, 'NA' operator, isnull( Fir.tester_program,'NA') tester_program, 
isnull(Senc.all_ft_programs,'NA') all_ft_programs,isnull(Fir.tester_id,'NA')  tester_id,
isnull( Fir.handel_id,'NA')  handel_id, 'NA' ft_process, nine.hold_count, 'NA' test_start_time,'NA' test_end_time,
'NA' pass_die,'NA' fail_die, 'NA' lot_yield,
 isnull(case when (six.stop_yieldtmp is null or six.stop_yieldtmp='') then four2.stop_yieldother else six.stop_yieldtmp end ,'NA')  stop_yield,
isnull(six.major_fail,'NA') major_fail,isnull(four.process_yield,'NA|NA') process_yield,isnull(Thrid.ft_yield,'NA' ) ft_yield,isnull(nine.pass_bins,'NA' ) pass_bins,
nine.os_bins os_bins,
(case when (nine.special_bins is null or nine.special_bins ='' or nine.special_bins ='NA' )  then six.special_binscon else nine.special_bins end) special_bins,
 'NA' data_base,'NA' test_time,five.pkg,(case when (nine.gpib_bin is null or nine.gpib_bin ='' or nine.gpib_bin ='NA' )  then 'NA' else SUBSTRING(nine.gpib_bin,1,1) end) gpib_bin

	--Step 1 获取该片wafer在该道FT step的 LotNum,PartNumber,MachineID,LinkedMachine,Cardid,RecipeID
	--input Dutno,ftstep
	--output  part_num,tester_id, prober_id, tester_program
	from  (SELECT top 1  his.PartNumber part_num, his.MachineID tester_id, 
	   his.LinkedMachine handel_id ,[RecipeID] tester_program,his.txntime
		 FROM   [WebMES].[dbo].wip_LotHistory his  
		   WHERE [LotNum]= @dutno  AND his.[StepNick] LIKE  @ftstep  + '%'
			 AND his.TxnAction IN ('LotTrackIn', 'LotTrackOut','[LotTrackIn]','[LotTrackOut]') and his.toqty>0 
			 order by his.txntime desc) Fir,

	--Step2 获取该片wafer经过的所有FT Process 
	--input dutno
	--output all_ft_programs
	(select isnull(max(case when CHARINDEX('FT1',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT2',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT3',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT4',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT5',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT6',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT7',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT8',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FT9',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ1',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ2',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ3',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ4',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ5',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ6',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ7',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ8',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'')+
	  isnull(max(case when CHARINDEX('FQ9',FromStepCode)>0  then FromStepCode+':'+ [RecipeID]+';' end ),'') all_ft_programs
	  FROM [WebMES].[dbo].[wip_LotHistory] his where TxnAction like '%trackin%' and 
	  ( (CHARINDEX('FT',FromStepCode)>0)or(CHARINDEX('FQ',FromStepCode)>0)) and LotNum = @dutno ) Senc,
  
	  --Step3 获取该片wafer经过的所有ft Yield
	--input Dutno, ftstep
	--output ft_yield
	  (select  isnull(max(case when ((Yieldcon='') or (Yieldcon=null) ) then 'NA'  
	  else SUBSTRING(Yieldcon,1,Len(Yieldcon)-1)  end ),'NA') ft_yield from 
	  (select   isnull(isnull(max(case when cpstep='FT1'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT2' then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT3' then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT4'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT5'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT6'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT7'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT8'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FT9'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ1'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ2' then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ3' then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ4'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ5'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ6'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ7'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ8'  then cpstep+'&'+Yield+';' end ),'')+
	  isnull(max(case when cpstep='FQ9'  then cpstep+'&'+Yield+';' end ),'') ,'NA')
	 Yieldcon from (select WaferID,CPStep cpstep,cast(MAX(WaferYield)as varchar(10))+'%' Yield 
	  from   [WebMES].[dbo].[wip_BinSummary] where  WaferID= @dutno  and CPStep <> @ftstep  
	  group by WaferID,CPStep) xx group by WaferID) ftyield ) Thrid ,

  
	--Step4 获取该片wafer经过的所有ft Yield
	--input Dutno,ftstep
	--output sites,process_yield

	( select   LotNum,isnull(max(case when (xx.sites is null or xx.sites='') then 'NA' else xx.sites end ),'NA') sites,
	  isnull(max(case when (xx.process_yield is null or xx.process_yield='') then 'NA|NA' else xx.process_yield end ),'NA|NA') process_yield
	      from ( SELECT   yy.LotNume LotNum,isnull(max(case when (yy.Sites is null or yy.Sites='') then 'NA' else yy.Sites end ),'NA') sites,
		isnull(max(case when  lotyield2='NA' then lotyield1 else lotyield2 end ) ,'NA')+'|'+ isnull(max(case when  wafyield2='NA' then wafyield1 else wafyield2 end ) ,'NA')
				 process_yield 
		 from (SELECT   wplist.LotNum LotNume,isnull(max(case when (flwsq.Sites is null or flwsq.Sites='') then 'NA' else flwsq.Sites end ),'NA') sites,
		 isnull(max(case when yieldcont.ControlItem='[By Wafer Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') wafyield1 ,
		 isnull(max(case when yieldcont.ControlItem='[By Wafer Final Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') wafyield2,
		 isnull(max(case when yieldcont.ControlItem='[By Lot Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') lotyield1,
		 isnull(max(case when yieldcont.ControlItem='[By Lot Final Yield]'  then  CAST(yieldcont.ControlLimit as nvarchar(10)) end ),'NA') lotyield2
		 FROM  [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[pdm_ProcessFlows] procflow,
		 [WebMES].[dbo].[pdm_ProcessFlowSequence] flwsq, [WebMES].[dbo].[pdm_ProcessYieldControl] yieldcont where  
		 wplist.ProcessFlow=procflow.ProcessFlowName   and flwsq.Sites is not null and flwsq.Sites <>''
		 and flwsq.isActive=1 and flwsq.FlowIndex=procflow.Item_Index
		 and wplist.ProcessRevision=procflow.Revision and (wplist.LotStatus>0  or wplist.LotStatus=-8)
		 and yieldcont.ControlMethod in ('<','<=')
		 and procflow.Item_Index=yieldcont.FlowIndex and yieldcont.IsActive=1 and procflow.isActive=1
		 and  wplist.LotNum= @dutno  and CPx= @ftstep  and flwsq.stepcode  like @ftstep +'%'
		 and ControlItem in ('[By Wafer Yield]','[By Lot Yield]','[By Wafer Final Yield]','[By Lot Final Yield]') group by  wplist.LotNum ) yy  group by LotNume ) xx
		 group by LotNum ) four,

	--Step4_2 获取该片wafer经过的所有stopYield
	--input  Dutno,ftstep
	--output sites,process_yield
	 ( 	 SELECT isnull(max(case when stop_yield1='NA'  then  stop_yield2 else stop_yield1 end ),'NA') stop_yieldother from 
	  (  SELECT wplist.LotNum,
		 isnull(max(case when yieldcont.ControlItem='[By Wafer Yield]'  then  CAST(yieldcont.ControlLimit-5 as nvarchar(10)) end ),'NA') stop_yield1 ,
		 isnull(max(case when yieldcont.ControlItem='[By Lot Yield]'  then  CAST(yieldcont.ControlLimit-5 as nvarchar(10)) end ),'NA') stop_yield2
		 FROM [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[pdm_ProcessFlows] procflow,
		 [WebMES].[dbo].[pdm_ProcessFlowSequence] flwsq, [WebMES].[dbo].[pdm_ProcessYieldControl] yieldcont where 
		 wplist.ProcessFlow=procflow.ProcessFlowName   and flwsq.Sites is not null and flwsq.Sites <>''
		 and flwsq.isActive=1 and flwsq.FlowIndex=procflow.Item_Index
		 and wplist.ProcessRevision=procflow.Revision and wplist.lotstatus>0 and yieldcont.ControlMethod in ('<','<=')
		 and procflow.Item_Index=yieldcont.FlowIndex and yieldcont.IsActive=1 and procflow.isActive=1
		 and   wplist.LotNum= @dutno and CPx= @ftstep and flwsq.stepcode  like @ftstep +'%'
		 and ControlItem in ('[By Wafer Yield]','[By Lot Yield]') group by wplist.LotNum)aa ) four2,

	--Step5 获取该片wafer prod配置信息
	--input  Dutno,ftstep
	--output chinese_name,chinese_shortname,map_or_ink,fab_device,asy_device,assigned_testers

	  ( select top 1 isnull(max(case when ( cust.CustCName  is null or  cust.CustCName  ='' )  then 'NA' else  cust.CustCName  end ),'NA') chinese_name,
	 isnull(max(case when ( cust.ShortName  is null or  cust.ShortName  ='' )  then 'NA' else  cust.ShortName  end ),'NA') chinese_shortname,
	isnull(max(case when ( pn.PartDescription is null or  pn.PartDescription  ='' )  then 'NA' else pn.PartDescription  end ),'NA') part_desc, 
	isnull(max(case when ( pn.packagename  is null or  pn.packagename ='' )  then 'NA' else  pn.packagename  end ),'NA') pkg,
	isnull(max(case when ( pn.FabDevice  is null or  pn.FabDevice  ='' )  then 'NA' else  pn.FabDevice  end ),'NA') fab_device,
	isnull(max(case when ( pn.AsyDevice  is null or  pn.AsyDevice  ='' )  then 'NA' else  pn.AsyDevice  end ),'NA') asy_device, 
	isnull(max(case when ( pn.AssignedTesters  is null or  pn.AssignedTesters  ='' )  then 'NA' else  pn.AssignedTesters  end ),'NA') assigned_testers
 from [WebMES].[dbo].pdm_Products pn ,[WebMES].[dbo].[pdm_Customers] cust,[WebMES].[dbo].[wip_LotList] wplist
	where wplist.LotNum= @dutno and pn.CustCode=cust.CustCode
	 and cust.isActive=1 and  pn.isActive = 1 and pn.PartNumber=wplist.PartNumber  
     and LotCat<>'I' and LotCat<>'R'-- and (pn.OpenShortBinCode like 'FT1' +'%' or pn.CpxOsBins  like 'FT1' +'%')	 
	 and (wplist.LotStatus>0  or wplist.LotStatus=-8)
	 group by pn.PartDescription) five,

	 --Step6 获取该片wafer process下的MES配置参数
	--input process_spec process_revision
	--output ItemOwner,pe_owner,tester_SoftWare_revision, tester_model, load_file,customer_tester_spec, map_reference,site_to_site,
			--continue_fail,stop_yield,major_fail,theory_test_time, special_binscon

	 ( select ItemOwner, isnull(max (case when flex.ItemName='PE_Owner'  then flex.ItemValue1  end ),'NA') pe_owner ,
	 isnull(max(case when flex.ItemName='Tester_Software_Revision'  then flex.ItemValue1  end ),'NA') tester_SoftWare_revision, 
	  isnull(max(case when flex.ItemName='TesterModel'  then flex.ItemValue1  end ),'NA') tester_model, 
	 isnull( max(case when flex.ItemName='LoadFile'  then flex.ItemValue1  end ),'NA') load_file,
	 isnull(max(case when flex.ItemName='Cust_TestSpec'  then flex.ItemValue1  end ),'NA') customer_tester_spec, 
	 isnull(max(case when flex.ItemName='LoadBoard'  then flex.ItemValue1  end ),'NA') load_bord,
	 isnull(max(case when flex.ItemName='Site-Site'  then flex.ItemValue1  end ),'NA') site_to_site,
	 isnull(max(case when flex.ItemName='Continuous_Fail'  then flex.ItemValue1  end ),'NA') continue_fail,
	 --此次有逻辑,如果找不到,找hold limit
  
	 (case when (isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') is null or isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') ='') 
	  then 'NA'  when CHARINDEX('CP',isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA'))<=0 
	  then isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA')
	  when CHARINDEX('FT1',isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') )<=0 then 'NA' else
	(SUBSTRING(isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') ,CHARINDEX('FT1',isnull(max(case when flex.ItemName='StopYield'  then flex.ItemValue1  end ),'NA') )+4,2 )) end ) stop_yieldtmp,

	isnull(max(case when flex.ItemName='Major_Fail'  then flex.ItemValue1  end ),'NA')  major_fail,
	isnull(max(case when flex.ItemName='Special_Bin'  then flex.ItemValue1  end ),'NA') special_binscon
	from [WebMES].[dbo].[pdm_FlexibleItems] flex,
	( select  wplist.ProcessFlow process_spec,wplist.ProcessRevision process_revision from 
	 [WebMES].[dbo].[wip_LotList] wplist, [WebMES].[dbo].[pdm_ProcessFlowSequence] seque,
	[WebMES].[dbo].[pdm_ProcessFlows] procflow
	 where  wplist.LotNum= @dutno and LotCat<>'I' and LotCat<>'R'  and (wplist.LotStatus>0  or wplist.LotStatus=-8)
	 and wplist.ProcessFlow=procflow.ProcessFlowName
	  and seque.FlowIndex=procflow.Item_Index
	 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and seque.StepCode like 'FT1'  +'%' ) wftotl
	where flex.Flag=1  and ItemName in ('PE_Owner','Tester_Software_Revision','TesterModel',
		'LoadFile','Cust_TestSpec','LoadBoard','Site-Site','Continuous_Fail',
		'ProberCard','StopYield','Major_Fail','TestTime/Pcs','WaferID_read','Wafer_Sequence','GPIB_Bin','Special_Bin')
	and ItemOwner= (wftotl.process_spec+':'+ CAST(wftotl.process_revision as nvarchar(10)))	group by ItemOwner ) six,
	--and ItemOwner= 'SFD_CFM347U04-00100:7'	group by ItemOwner


 
	 --Step8 获取该片wafer process short flow
	--input  Dutno
	--output customer_code,ship_lot,customer_to_customer_po_number

	(  select customer_code,ship_lot, isnull(max(case when ( CustPO  is null or CustPO  ='' ) 
		then 'NA' else  CustPO  end ),'NA') customer_to_customer_po_number
		from (select top 1 wpl.customer_code, wpl.ship_lot,max(workor.CustCustPO)  CustPO from 
	(SELECT  custcode customer_code,max(wplist.PONumber) PONumber, isnull(max(case when ( CustLotPostCP  is null or CustLotPostCP  ='' ) 
		then wplist.CustLotNum else  CustLotPostCP  end ),'NA')  ship_lot
		FROM [WebMES].[dbo].[wip_LotList] wplist
		where LotNum= @dutno   group by custcode)  wpl
		left join [WebMES].[dbo].[pln_WorkOrders] workor on wpl.customer_code=workor.CustCode and wpl.PONumber=workor.PONumber
		group by wpl.customer_code, wpl.ship_lot)zz group by customer_code,ship_lot  ) eight,

    	


	 --Step9 获取该片wafer process的主要wafer信息
	--input  Dutno,ftstep
	--output ***
		(  select top 1  wplist.CustLotNum lot_id, wplist.LotNum inner_lot,wplist.MotherLot inner_monther_lot, wplist.CustPart device_name,
		isnull((case when ( wplist.WaferSequence  is null or   wplist.WaferSequence  ='' )  then '1-25' else   wplist.WaferSequence  end ),'1-25') wafer_sequence,
		wplist.PartNumber part_num ,StartTime lot_starttime, wplist.WorkOrder worker_order,
	   wplist.ProcessFlow process_spec,wplist.ProcessRevision process_revision,CONVERT(CHAR,wplist.LotStatus) lot_status, wplist.HoldCount hold_count,
	   wplist.PCS wafer_pcs,procflow.GrossDie stand_gross_die,
	   (case when ( seque.ProberDevice is null or  seque.ProberDevice ='' or seque.ProberDevice ='NA' )  then 'NA'  
	when ((len( seque.ProberDevice)<4)  or (CHARINDEX(@ftstep, seque.ProberDevice )<1 )) then  seque.ProberDevice else 
	(SUBSTRING( SUBSTRING( seque.ProberDevice,CHARINDEX(@ftstep, seque.ProberDevice )+4,len( seque.ProberDevice ) ),1,
	case when CHARINDEX(';',SUBSTRING( seque.ProberDevice ,CHARINDEX(@ftstep, seque.ProberDevice)+4,len( seque.ProberDevice ) ) )>1 then
	CHARINDEX(';',SUBSTRING( seque.ProberDevice ,CHARINDEX(@ftstep, seque.ProberDevice )+4,len( seque.ProberDevice ) ) )-1
	else len(SUBSTRING( seque.ProberDevice ,CHARINDEX(@ftstep, seque.ProberDevice )+4,len( seque.ProberDevice ) ))  end ))
	  end ) handel_device ,
	  isnull((case when ( wplist.WipStage  is null or   wplist.WipStage  ='' )  then 'NA' else   wplist.WipStage  end ),'NA') 	wip_stage, 
	  isnull((case when (wplist.WipStep  is null or  wplist.WipStep  ='' )  then 'NA' else  wplist.WipStep  end ),'NA') wip_step,
	  isnull((case when (wplist.PONumber  is null or  wplist.PONumber  ='' )  then 'NA' else  wplist.PONumber  end ),'NA') po_number ,
	  isnull((case when ( procflow.isTrimed  is null or  procflow.isTrimed  ='' )  then 0 else  procflow.isTrimed  end ),0) is_trimed,
	  isnull((case when ( procflow.isOTP  is null or  procflow.isOTP  ='' )  then 0 else  procflow.isOTP  end ),0) is_otp,
      isnull((case when ( procflow.isCUP  is null or  procflow.isCUP  ='' )  then 0 else  procflow.isCUP  end ),0) is_cop,
	    prdevic.PassBins  pass_bins,prdevic.SpecialBins  special_bins,
	  prdevic.GbibBin  gpib_bin,procflow.Item_Index,seque.OSBins os_bins, seque.Sites sites,
		procflow.WaferSize wf_size,procflow.WholeFlow3 process_short_flow
		 from [WebMES].[dbo].[wip_LotList] wplist ,
		[WebMES].[dbo].[pdm_ProcessFlowSequence] seque,[WebMES].[dbo].[pdm_ProcessFlows] procflow,[WebMES].[dbo].[pdm_HandlerDevice] prdevic
	 where wplist.LotNum= @dutno  and seque.OSBins <>''and LotCat<>'I' and LotCat<>'R'
	 and  wplist.ProcessFlow=procflow.ProcessFlowName and seque.FlowIndex=procflow.Item_Index and (wplist.LotStatus>0  or wplist.LotStatus=-8)
      and  seque.ProberDevice=prdevic.HandlerDevice 
	 	 and prdevic.isActive=1  and prdevic.IsDefault=1
	 and wplist.ProcessRevision=procflow.Revision and seque.isActive=1 and procflow.isActive=1 and seque.StepCode   like @ftstep +'%' order by StartTime desc  ) nine

end;
go

