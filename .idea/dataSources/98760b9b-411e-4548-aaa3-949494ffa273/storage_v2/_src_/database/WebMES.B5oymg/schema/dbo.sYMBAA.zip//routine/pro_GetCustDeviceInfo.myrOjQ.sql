CREATE   procedure [dbo].[pro_GetCustDeviceInfo]
@waferid varchar(50),
@cpstep varchar(50)
as


  SELECT top 1  wip_LotList.CustCode CustCode , wip_LotList.CustPart CustPart, 
                wip_LotList.CustLotNum Lot
FROM      wip_LotWaferIDs INNER JOIN
                wip_LotList ON wip_LotWaferIDs.LotNum = wip_LotList.LotNum INNER JOIN
                pdm_ProcessFlows ON wip_LotList.ProcessFlow = pdm_ProcessFlows.ProcessFlowName AND 
                wip_LotList.ProcessRevision = pdm_ProcessFlows.Revision INNER JOIN
                pdm_ProcessFlowSequence ON pdm_ProcessFlows.Item_Index = pdm_ProcessFlowSequence.FlowIndex
WHERE   (wip_LotWaferIDs.WaferID = @waferid ) AND (wip_LotList.LotStatus > 0) AND (pdm_ProcessFlows.isActive = 1) AND 
                (pdm_ProcessFlowSequence.isActive = 1) AND (pdm_ProcessFlowSequence.StepCode LIKE @cpstep+'%' )
ORDER BY wip_LotList.CreateTime DESC
go

